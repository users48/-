﻿namespace laba1
{
    internal class KeyCharEventArgs
    {
        public char KeyChar { get; internal set; }
    }
}