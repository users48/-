﻿namespace laba1
{
    internal class TextCompositionEventArgs
    {
    }
}