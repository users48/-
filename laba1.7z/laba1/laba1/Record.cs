﻿namespace laba1
{
    internal class Record
    {
        public int Index { get; set; }
    }
}