﻿namespace laba1
{
    internal class PageOffsetList
    {
        public PageOffsetList()
        {
        }
    }
}