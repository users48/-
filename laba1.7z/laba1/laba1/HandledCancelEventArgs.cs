﻿namespace laba1
{
    internal class HandledCancelEventArgs
    {
        public bool Handled { get; internal set; }
        public char KeyChar { get; internal set; }
    }
}